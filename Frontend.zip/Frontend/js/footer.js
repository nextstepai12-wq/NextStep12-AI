/* footer.js — يحقن الفوتر الموحّد ويصحّح المسارات تلقائياً */
(function () {
  var inPages = window.location.pathname.includes('/pages/');
  var root = inPages ? '../' : '';
  var pg = inPages ? '' : 'pages/';

  document.write(
    '<footer class="site-footer">' +
      '<div class="footer-inner">' +
        '<div class="footer-top">' +

          '<div class="footer-col footer-brand">' +
            '<a href="' + root + 'index.html" class="brand-mark">' +
              '<img src="' + root + 'assets/logo.png" alt="" class="brand-logo">' +
              '<span class="brand-text">NextStep <span>AI</span></span>' +
            '</a>' +
            '<p class="tagline">خطوتك الذكية لمستقبلك الجامعي. منصة تساعد الطلاب على اكتشاف التخصص الجامعي الأنسب لهم عبر اختبارات ذكية.</p>' +
            '<div class="social-row">' +
              '<a href="#" aria-label="Instagram"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1"/></svg></a>' +
              '<a href="#" aria-label="X"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4l16 16M20 4L4 20"/></svg></a>' +
              '<a href="#" aria-label="LinkedIn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="3"/><line x1="7" y1="10" x2="7" y2="17"/><circle cx="7" cy="7" r="0.8" fill="currentColor"/><path d="M11 17v-4a2 2 0 0 1 4 0v4"/><line x1="11" y1="10" x2="11" y2="17"/></svg></a>' +
              '<a href="#" aria-label="YouTube"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="6" width="20" height="12" rx="4"/><path d="M10 9.5l5 2.5-5 2.5z" fill="currentColor" stroke="none"/></svg></a>' +
            '</div>' +
          '</div>' +

          '<div class="footer-col">' +
            '<h4>روابط الموقع</h4>' +
            '<ul>' +
              '<li><a href="' + root + 'index.html"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/></svg>الرئيسية</a></li>' +
              '<li><a href="' + pg + 'quiz.html"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M8 2v4M16 2v4M3 10h18"/></svg>الاختبار الذكي</a></li>' +
              '<li><a href="' + pg + 'universities.html"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 21h18M5 21V7l7-4 7 4v14"/></svg>الجامعات</a></li>' +
              '<li><a href="' + pg + 'about.html"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>عن المنصة</a></li>' +
            '</ul>' +
          '</div>' +

          '<div class="footer-col">' +
            '<h4>معلومات</h4>' +
            '<ul>' +
              '<li><a href="#"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l8 4v6c0 5-3.5 8-8 10-4.5-2-8-5-8-10V6l8-4z"/></svg>سياسة الخصوصية</a></li>' +
              '<li><a href="#"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg>الشروط والأحكام</a></li>' +
              '<li><a href="#"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M9.5 9a2.5 2.5 0 0 1 5 0c0 1.5-2 2-2 3.5M12 17h.01"/></svg>الأسئلة الشائعة</a></li>' +
            '</ul>' +
          '</div>' +

          '<div class="footer-col">' +
            '<h4>تواصل معنا</h4>' +
            '<div class="contact-item"><div class="icon-wrap"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M22 6l-10 7L2 6"/></svg></div><a href="mailto:nextstepai12@gmail.com">nextstepai12@gmail.com</a></div>' +
            '<div class="contact-item"><div class="icon-wrap"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.12.9.33 1.77.62 2.6a2 2 0 0 1-.45 2.11L8.09 9.62a16 16 0 0 0 6 6l1.19-1.19a2 2 0 0 1 2.11-.45c.83.29 1.7.5 2.6.62A2 2 0 0 1 22 16.92z"/></svg></div><a href="tel:+970000000000">+970 00 000 0000</a></div>' +
            '<div class="contact-item"><div class="icon-wrap"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg></div><span>فلسطين</span></div>' +
          '</div>' +

        '</div>' +

        '<div class="footer-bottom">' +
          '<p>© 2026 NextStep AI. جميع الحقوق محفوظة.</p>' +
          '<div class="legal-links">' +
            '<a href="#">الشروط والأحكام</a>' +
            '<a href="#">سياسة الخصوصية</a>' +
            '<a href="#">خريطة الموقع</a>' +
          '</div>' +
        '</div>' +
      '</div>' +
    '</footer>'
  );
})();
