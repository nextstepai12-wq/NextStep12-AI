/**
 * include-partials.js
 * بعد التعديل: الهيدر والفوتر بيتكتبوا مباشرة بالصفحة عن طريق
 * header.js و footer.js (document.write) — بدون أي طلب شبكة (fetch).
 * هاد الملف بس مسؤول عن: تفعيل الرابط النشط + حالة تسجيل الدخول.
 */

(function () {
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';

  function markActiveLinks(container) {
    if (!container) return;
    container.querySelectorAll('a[href]').forEach((link) => {
      const href = link.getAttribute('href').split('/').pop();
      if (href === currentPage) {
        link.classList.add('active');
      }
    });
  }

  function initHeaderBehavior() {
    const token = localStorage.getItem('token');
    const signInBtn = document.querySelector('.btn-signin');
    if (token && signInBtn) {
      signInBtn.textContent = 'حسابي';
      signInBtn.setAttribute('href', 'profile.html');
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    // الهيدر والفوتر أصلاً موجودين بالـ DOM هلأ (كتبهم header.js و footer.js)
    markActiveLinks(document.querySelector('.site-header'));
    initHeaderBehavior();
  });
})();
